def int(request):
    pass