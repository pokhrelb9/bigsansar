from django import template
from django.contrib.sites.shortcuts import get_current_site
from bigsansar.contrib.blogs.models import post

register = template.Library()


@register.simple_tag(takes_context=True)
def get_blog(context):
    current_site = get_current_site(context['request'])
    get_pages_filter = post.objects.filter(domain__domain=current_site)

    return get_pages_filter
