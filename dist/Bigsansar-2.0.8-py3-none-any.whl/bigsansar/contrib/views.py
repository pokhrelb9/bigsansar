
def index_page():
    return "<h1>Welcome to the Index Page!</h1>"

def about_page():
    return "<h1>About Us</h1><p>This is the About Us page.</p>"

def contact_page():
    return "<h1>Contact Us</h1><p>You can reach us at contact@example.com.</p>"



def not_found_page():
    return "<h1>404 Not Found</h1><p>The requested page was not found.</p>"