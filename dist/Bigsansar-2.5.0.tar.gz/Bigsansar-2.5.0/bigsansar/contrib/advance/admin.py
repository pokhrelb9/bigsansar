# from django.contrib import admin

# from bigsansar.contrib.advance.models import SidebarSettings

# # Register your models ha

# admin.site.register(SidebarSettings)