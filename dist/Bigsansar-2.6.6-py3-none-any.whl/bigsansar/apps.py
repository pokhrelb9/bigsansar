from django.apps import AppConfig


class BigsansarConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bigsansar'
    verbose_name_ = 'Basic Functions'
