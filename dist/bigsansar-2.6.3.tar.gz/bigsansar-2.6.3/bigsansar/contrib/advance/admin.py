# from django.contrib import admin

# from bigsansar.contrib.advance.models import cloudflare_api

# # Register your models ha

# admin.site.register(cloudflare_api)